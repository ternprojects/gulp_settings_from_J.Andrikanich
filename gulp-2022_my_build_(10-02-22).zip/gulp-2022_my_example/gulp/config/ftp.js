export let configFTP = {
	host: 'z93832qp.beget.tech', // Адрес FTP сервера
	user: 'z93832qp', // Имя пользователя
	password: 'hBKqUOKJ', // Пароль
	parallel: 5, // Кол-во одновременных потоков
}
